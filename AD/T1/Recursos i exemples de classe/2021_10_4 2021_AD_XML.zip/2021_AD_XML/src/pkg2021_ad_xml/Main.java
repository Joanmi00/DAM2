/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2021_ad_xml;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 *
 * @author joange
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try {
            
            XMLLib llibreria= new XMLLib();
            JSONLib llibreria_json= new JSONLib();
            
            Document elXml=llibreria.ObreXML("moduls.xml");
            
            //llibreria.mostrarXML(elXml);
            
            ArrayList<Modul> elsModuls=llibreria.cargarXML(elXml);
            
            
            llibreria.saveXML(elsModuls, "moduls_copia.xml");
            
            llibreria_json.saveJSON(elsModuls, "moduls.json");
            
            elsModuls=llibreria_json.loadJSON("moduls.json");
            
            for (Modul m : elsModuls) {
                System.out.println(m);
            }
            
            
            
        } catch (IOException | SAXException | ParserConfigurationException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
}
