/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg2021_ad_xml;

import java.io.Serializable;
import org.json.JSONException;
import org.w3c.dom.Element;
import org.json.JSONObject;

/**
 *
 * @author joange
 */
class Modul implements Serializable{
    private String nom;
    private int hores;
    private double nota;

    public Modul(){
        // Constructor buit
    }

    public Modul(String nom, int hores, double nota){
        this.nom=nom;
        this.hores=hores;
        this.nota=nota;
    }
    
    public Modul(Element e){
        // TO-DO
    }
    
    public Modul(JSONObject jso) throws JSONException{
        this.nom=jso.getString("nom");
        this.hores=jso.getInt("hores");
        this.nota=jso.getDouble("qualificacio");
    }

    @Override
    public String toString() {
        return "Modul{" + "nom=" + nom + ", hores=" + hores + ", nota=" + nota + '}';
    }

    public String getModul() {return this.nom;}
    public int getHores() {return this.hores;}
    public double getNota() {return this.nota;}
    
    
    public JSONObject toJSON() throws JSONException{
        
        JSONObject modul= new JSONObject();
        
        modul.put("nom", this.nom);
        modul.put("hores", this.hores);
        modul.put("qualificacio", this.nota);
        
        return modul;
        
    }
} 