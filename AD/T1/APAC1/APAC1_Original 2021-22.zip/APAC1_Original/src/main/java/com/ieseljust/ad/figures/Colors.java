package com.ieseljust.ad.figures;

public class Colors {
    public static String Black = "\u001b[30m";
    public static String Red = "\u001b[31m";
    public static String Green = "\u001b[32m";
    public static String Yellow = "\u001b[33m";
    public static String Blue = "\u001b[34m";
    public static String Magenta = "\u001b[35m";
    public static String Cyan  = "\u001b[36m";
    public static String White = "\u001b[37m";
    public static String Reset = "\u001b[0m";

    public static String Bright_Black = "\u001b[30;1m";
    public static String Bright_Red ="\u001b[31;1m";
    public static String Bright_Green = "\u001b[32;1m";
    public static String Bright_Yellow = "\u001b[33;1m";
    public static String Bright_Blue = "\u001b[34;1m";
    public static String Bright_Magenta = "\u001b[35;1m";
    public static String Bright_Cyan = "\u001b[36;1m";
    public static String Bright_White = "\u001b[37;1m";
}